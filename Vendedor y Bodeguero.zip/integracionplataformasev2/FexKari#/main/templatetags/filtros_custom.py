from django import template

register = template.Library()

@register.filter
def contiene_codigo(productos, prefix):
    return [p for p in productos if p.codigo.startswith(prefix)]
