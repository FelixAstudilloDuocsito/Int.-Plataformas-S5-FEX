from django.contrib import admin
from .models import Categoria, Producto, ImagenProducto, Carrito, ItemCarrito



class ImagenProductoInline(admin.TabularInline):  
    model = ImagenProducto
    extra = 1  



class ProductoAdmin(admin.ModelAdmin):
    inlines = [ImagenProductoInline]


admin.site.register(Categoria)
admin.site.register(Producto, ProductoAdmin)  
admin.site.register(ImagenProducto)
admin.site.register(Carrito)
admin.site.register(ItemCarrito)
