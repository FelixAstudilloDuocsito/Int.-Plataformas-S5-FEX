// Sample data for products
const products = [
  { id: 1, name: "Martillo Stanley", category: "Herramientas", price: 12500, stock: 45 },
  { id: 2, name: "Destornillador Phillips", category: "Herramientas", price: 4500, stock: 78 },
  { id: 3, name: 'Llave Inglesa 12"', category: "Herramientas", price: 8900, stock: 23 },
  { id: 4, name: "Pintura Blanca 1L", category: "Pinturas", price: 15000, stock: 56 },
  { id: 5, name: 'Tornillos 1" (100 unidades)', category: "Fijaciones", price: 3200, stock: 120 },
  { id: 6, name: "Sierra Circular", category: "Herramientas Eléctricas", price: 89000, stock: 12 },
  { id: 7, name: "Taladro Inalámbrico", category: "Herramientas Eléctricas", price: 65000, stock: 18 },
  { id: 8, name: "Cinta Métrica 5m", category: "Medición", price: 5500, stock: 34 },
  { id: 9, name: "Nivel de Burbuja", category: "Medición", price: 7800, stock: 27 },
  { id: 10, name: "Escalera Plegable", category: "Equipamiento", price: 45000, stock: 8 },
];

// Sample data for orders
let orders = [
  { 
    id: 1, 
    customer: "Juan Pérez", 
    address: "Av. Providencia 1234, Santiago", 
    products: [
      { id: 1, name: "Martillo Stanley", price: 12500, quantity: 1 },
      { id: 5, name: 'Tornillos 1" (100 unidades)', price: 3200, quantity: 2 }
    ],
    status: "pending",
    date: "2023-05-14"
  },
  { 
    id: 2, 
    customer: "María González", 
    address: "Los Leones 456, Providencia", 
    products: [
      { id: 4, name: "Pintura Blanca 1L", price: 15000, quantity: 3 }
    ],
    status: "pending",
    date: "2023-05-14"
  },
  { 
    id: 3, 
    customer: "Carlos Rodríguez", 
    address: "Manuel Montt 789, Ñuñoa", 
    products: [
      { id: 7, name: "Taladro Inalámbrico", price: 65000, quantity: 1 },
      { id: 8, name: "Cinta Métrica 5m", price: 5500, quantity: 1 }
    ],
    status: "pending",
    date: "2023-05-13"
  },
  { 
    id: 4, 
    customer: "Ana Martínez", 
    address: "Irarrázaval 1234, Ñuñoa", 
    products: [
      { id: 6, name: "Sierra Circular", price: 89000, quantity: 1 }
    ],
    status: "pending",
    date: "2023-05-13"
  },
  { 
    id: 5, 
    customer: "Pedro Sánchez", 
    address: "Apoquindo 5678, Las Condes", 
    products: [
      { id: 2, name: "Destornillador Phillips", price: 4500, quantity: 2 },
      { id: 3, name: 'Llave Inglesa 12"', price: 8900, quantity: 1 },
      { id: 9, name: "Nivel de Burbuja", price: 7800, quantity: 1 }
    ],
    status: "pending",
    date: "2023-05-12"
  }
];

// DOM Elements
const tabButtons = document.querySelectorAll('.tab-button');
const tabContents = document.querySelectorAll('.tab-content');
const productSearchInput = document.getElementById('product-search');
const orderSearchInput = document.getElementById('order-search');
const productsTableBody = document.querySelector('#products-table tbody');
const ordersContainer = document.getElementById('orders-container');
const dialogOverlay = document.getElementById('dialog-overlay');
const dialogTitle = document.getElementById('dialog-title');
const dialogDescription = document.getElementById('dialog-description');
const dialogContent = document.getElementById('dialog-content');
const dialogConfirmButton = document.getElementById('dialog-confirm');
const dialogCancelButton = document.getElementById('dialog-cancel');
const toast = document.getElementById('toast');
const toastTitle = document.getElementById('toast-title');
const toastMessage = document.getElementById('toast-message');

// Current state
let selectedOrder = null;
let dialogAction = '';

// Initialize the app
function init() {
  renderProducts(products);
  renderOrders(orders);
  setupEventListeners();
}

// Setup event listeners
function setupEventListeners() {
  // Tab switching
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      switchTab(tabId);
    });
  });

  // Search functionality
  productSearchInput.addEventListener('input', () => {
    const searchTerm = productSearchInput.value.toLowerCase();
    const filteredProducts = products.filter(product => 
      product.name.toLowerCase().includes(searchTerm)
    );
    renderProducts(filteredProducts);
  });

  orderSearchInput.addEventListener('input', () => {
    const searchTerm = orderSearchInput.value.toLowerCase();
    const filteredOrders = orders.filter(order => 
      order.customer.toLowerCase().includes(searchTerm) ||
      order.products.some(p => p.name.toLowerCase().includes(searchTerm))
    );
    renderOrders(filteredOrders);
  });

  // Dialog buttons
  dialogCancelButton.addEventListener('click', () => {
    closeDialog();
  });

  dialogConfirmButton.addEventListener('click', () => {
    confirmOrderAction();
  });
}

// Switch between tabs
function switchTab(tabId) {
  tabButtons.forEach(button => {
    if (button.getAttribute('data-tab') === tabId) {
      button.classList.add('active');
    } else {
      button.classList.remove('active');
    }
  });

  tabContents.forEach(content => {
    if (content.id === tabId) {
      content.classList.add('active');
    } else {
      content.classList.remove('active');
    }
  });
}

// Render products table
function renderProducts(productsToRender) {
  productsTableBody.innerHTML = '';
  
  if (productsToRender.length === 0) {
    const emptyRow = document.createElement('tr');
    emptyRow.innerHTML = `
      <td colspan="4" class="text-center">No se encontraron productos</td>
    `;
    productsTableBody.appendChild(emptyRow);
    return;
  }

  productsToRender.forEach(product => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td class="font-medium">${product.name}</td>
      <td>${product.category}</td>
      <td class="text-right">$${product.price.toLocaleString()}</td>
      <td class="text-right">
        <span class="badge ${product.stock < 20 ? 'badge-destructive' : 'badge-default'}">
          ${product.stock}
        </span>
      </td>
    `;
    productsTableBody.appendChild(row);
  });
}

// Render orders
function renderOrders(ordersToRender) {
  ordersContainer.innerHTML = '';
  
  if (ordersToRender.length === 0) {
    const emptyState = document.createElement('div');
    emptyState.className = 'empty-state';
    emptyState.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
      <h3>No hay pedidos</h3>
      <p>No se encontraron pedidos que coincidan con tu búsqueda.</p>
    `;
    ordersContainer.appendChild(emptyState);
    return;
  }

  ordersToRender.forEach(order => {
    const orderCard = document.createElement('div');
    orderCard.className = `order-card ${order.status !== 'pending' ? 'inactive' : ''}`;
    
    // Calculate total
    const total = order.products.reduce((sum, product) => sum + (product.price * product.quantity), 0);
    
    // Create order header
    const orderHeader = document.createElement('div');
    orderHeader.className = 'order-header';
    
    const orderHeaderContent = document.createElement('div');
    orderHeaderContent.className = 'order-header-content';
    
    const orderTitle = document.createElement('div');
    orderTitle.className = 'order-title';
    orderTitle.textContent = `Pedido #${order.id} - ${order.customer}`;
    
    const orderActions = document.createElement('div');
    orderActions.className = 'order-actions';
    
    if (order.status === 'pending') {
      // Accept button
      const acceptButton = document.createElement('button');
      acceptButton.className = 'button button-outline button-sm button-icon';
      acceptButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>Aceptar</span>
      `;
      acceptButton.addEventListener('click', () => handleOrderAction(order, 'accept'));
      orderActions.appendChild(acceptButton);
      
      // Reject button
      const rejectButton = document.createElement('button');
      rejectButton.className = 'button button-outline button-sm button-icon button-destructive';
      rejectButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        <span>Rechazar</span>
      `;
      rejectButton.addEventListener('click', () => handleOrderAction(order, 'reject'));
      orderActions.appendChild(rejectButton);
    } else {
      // Status badge
      const statusBadge = document.createElement('span');
      statusBadge.className = `badge ${order.status === 'processing' ? 'badge-secondary' : 'badge-destructive'}`;
      statusBadge.textContent = order.status === 'processing' ? 'En proceso' : 'Rechazado';
      orderActions.appendChild(statusBadge);
    }
    
    orderHeaderContent.appendChild(orderTitle);
    orderHeaderContent.appendChild(orderActions);
    
    const orderDetails = document.createElement('div');
    orderDetails.className = 'order-details';
    orderDetails.innerHTML = `
      <p>Dirección: ${order.address}</p>
      <p>Fecha: ${order.date}</p>
    `;
    
    orderHeader.appendChild(orderHeaderContent);
    orderHeader.appendChild(orderDetails);
    
    // Create order content with products table
    const orderContent = document.createElement('div');
    orderContent.className = 'order-content';
    
    const tableContainer = document.createElement('div');
    tableContainer.className = 'table-container';
    
    const table = document.createElement('table');
    
    const tableHead = document.createElement('thead');
    tableHead.innerHTML = `
      <tr>
        <th>Producto</th>
        <th class="text-right">Precio</th>
        <th class="text-right">Cantidad</th>
        <th class="text-right">Subtotal</th>
      </tr>
    `;
    
    const tableBody = document.createElement('tbody');
    
    // Add product rows
    order.products.forEach(product => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td class="font-medium">${product.name}</td>
        <td class="text-right">$${product.price.toLocaleString()}</td>
        <td class="text-right">${product.quantity}</td>
        <td class="text-right">$${(product.price * product.quantity).toLocaleString()}</td>
      `;
      tableBody.appendChild(row);
    });
    
    // Add total row
    const totalRow = document.createElement('tr');
    totalRow.innerHTML = `
      <td colspan="3" class="text-right font-bold">Total:</td>
      <td class="text-right font-bold">$${total.toLocaleString()}</td>
    `;
    tableBody.appendChild(totalRow);
    
    table.appendChild(tableHead);
    table.appendChild(tableBody);
    tableContainer.appendChild(table);
    orderContent.appendChild(tableContainer);
    
    // Assemble the order card
    orderCard.appendChild(orderHeader);
    orderCard.appendChild(orderContent);
    
    ordersContainer.appendChild(orderCard);
  });
}

// Handle order action (accept or reject)
function handleOrderAction(order, action) {
  selectedOrder = order;
  dialogAction = action;
  
  if (action === 'accept') {
    dialogTitle.textContent = '¿Derivar pedido al bodeguero?';
    dialogDescription.textContent = 'Este pedido será enviado al bodeguero para su preparación y despacho.';
    dialogConfirmButton.textContent = 'Derivar al bodeguero';
    dialogConfirmButton.className = 'button';
  } else {
    dialogTitle.textContent = '¿Rechazar pedido?';
    dialogDescription.textContent = 'Este pedido será rechazado y no se procesará.';
    dialogConfirmButton.textContent = 'Rechazar pedido';
    dialogConfirmButton.className = 'button button-destructive';
  }
  
  // Calculate total
  const total = selectedOrder.products.reduce((sum, product) => sum + (product.price * product.quantity), 0);
  
  dialogContent.innerHTML = `
    <p><strong>Cliente:</strong> ${selectedOrder.customer}</p>
    <p><strong>Dirección:</strong> ${selectedOrder.address}</p>
    <p><strong>Total:</strong> $${total.toLocaleString()}</p>
  `;
  
  openDialog();
}

// Open dialog
function openDialog() {
  dialogOverlay.classList.remove('hidden');
  dialogOverlay.classList.add('dialog-overlay');
}

// Close dialog
function closeDialog() {
  dialogOverlay.classList.add('hidden');
  dialogOverlay.classList.remove('dialog-overlay');
}

// Confirm order action
function confirmOrderAction() {
  if (dialogAction === 'accept') {
    // Update order status to "processing"
    orders = orders.map(order => 
      order.id === selectedOrder.id ? {...order, status: 'processing'} : order
    );
    showToast('Pedido aceptado', `El pedido #${selectedOrder.id} ha sido enviado al bodeguero para su despacho.`);
  } else if (dialogAction === 'reject') {
    // Update order status to "rejected"
    orders = orders.map(order => 
      order.id === selectedOrder.id ? {...order, status: 'rejected'} : order
    );
    showToast('Pedido rechazado', `El pedido #${selectedOrder.id} ha sido rechazado.`);
  }
  
  closeDialog();
  renderOrders(orders);
}

// Show toast notification
function showToast(title, message) {
  toastTitle.textContent = title;
  toastMessage.textContent = message;
  
  toast.classList.remove('hidden');
  
  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', init);