// DOM Elements
const orderSearchInput = document.getElementById('order-search');
const ordersContainer = document.getElementById('orders-container');
const filterButtons = document.querySelectorAll('.filter-button');
const dialogOverlay = document.getElementById('dialog-overlay');
const dialogTitle = document.getElementById('dialog-title');
const dialogDescription = document.getElementById('dialog-description');
const dialogContent = document.getElementById('dialog-content');
const dialogConfirmButton = document.getElementById('dialog-confirm');
const dialogCancelButton = document.getElementById('dialog-cancel');
const dialogCloseButton = document.getElementById('dialog-close');
const toast = document.getElementById('toast');
const toastTitle = document.getElementById('toast-title');
const toastMessage = document.getElementById('toast-message');
const toastCloseButton = document.getElementById('toast-close');

// Current state
let selectedOrder = null;
let dialogAction = '';
let currentFilter = 'all';

// Example orders data (for demonstration)
const exampleOrders = [
  {
    id: 1001,
    cliente: "Carlos Rodríguez",
    direccion: "Av. Providencia 1234, Santiago",
    fecha: "15/05/2025",
    estado: "pending",
    productos: [
      {
        nombre: "Martillo Stanley",
        precio: 12990,
        cantidad: 2
      },
      {
        nombre: "Juego de destornilladores",
        precio: 15990,
        cantidad: 1
      },
      {
        nombre: "Taladro inalámbrico",
        precio: 59990,
        cantidad: 1
      }
    ]
  },
  {
    id: 1002,
    cliente: "María González",
    direccion: "Los Alerces 567, Viña del Mar",
    fecha: "14/05/2025",
    estado: "accepted",
    productos: [
      {
        nombre: "Sierra circular",
        precio: 89990,
        cantidad: 1
      },
      {
        nombre: "Disco de corte",
        precio: 5990,
        cantidad: 3
      }
    ]
  },
  {
    id: 1003,
    cliente: "Juan Pérez",
    direccion: "Calle Los Olmos 789, Concepción",
    fecha: "13/05/2025",
    estado: "dispatched",
    productos: [
      {
        nombre: "Escalera plegable",
        precio: 45990,
        cantidad: 1
      },
      {
        nombre: "Caja de herramientas",
        precio: 29990,
        cantidad: 1
      }
    ]
  },
  {
    id: 1004,
    cliente: "Ana Martínez",
    direccion: "Pasaje Las Flores 123, Temuco",
    fecha: "12/05/2025",
    estado: "rejected",
    productos: [
      {
        nombre: "Pintura látex 20L",
        precio: 49990,
        cantidad: 2
      },
      {
        nombre: "Rodillo pintura",
        precio: 7990,
        cantidad: 3
      },
      {
        nombre: "Brochas set x5",
        precio: 12990,
        cantidad: 1
      }
    ]
  }
];

// Initialize the app
function init() {
  loadOrders();
  setupEventListeners();
}

// Setup event listeners
function setupEventListeners() {
  // Search functionality
  orderSearchInput.addEventListener('input', debounce(() => {
    loadOrders(orderSearchInput.value);
  }, 300));

  // Filter buttons
  filterButtons.forEach(button => {
    button.addEventListener('click', () => {
      const filter = button.getAttribute('data-filter');
      setActiveFilter(filter);
      loadOrders(orderSearchInput.value);
    });
  });

  // Dialog buttons
  dialogCancelButton.addEventListener('click', () => {
    closeDialog();
  });

  dialogCloseButton.addEventListener('click', () => {
    closeDialog();
  });

  dialogConfirmButton.addEventListener('click', () => {
    confirmOrderAction();
  });

  // Toast close button
  toastCloseButton.addEventListener('click', () => {
    toast.classList.add('hidden');
  });
}

// Set active filter
function setActiveFilter(filter) {
  currentFilter = filter;
  
  filterButtons.forEach(button => {
    if (button.getAttribute('data-filter') === filter) {
      button.classList.add('active');
    } else {
      button.classList.remove('active');
    }
  });
}

// Debounce function to limit API calls
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Load orders (using example data for demonstration)
function loadOrders(searchTerm = '') {
  try {
    // Filter orders based on search term and current filter
    let filteredOrders = exampleOrders;
    
    // Apply search filter if provided
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filteredOrders = filteredOrders.filter(order => 
        order.cliente.toLowerCase().includes(term) || 
        order.id.toString().includes(term) ||
        order.productos.some(product => product.nombre.toLowerCase().includes(term))
      );
    }
    
    // Apply status filter if not "all"
    if (currentFilter !== 'all') {
      filteredOrders = filteredOrders.filter(order => order.estado === currentFilter);
    }
    
    renderOrders(filteredOrders);
  } catch (error) {
    console.error('Error loading orders:', error);
    showToast('Error', 'No se pudieron cargar los pedidos.');
  }
}

// Render orders
function renderOrders(orders) {
  ordersContainer.innerHTML = '';
  
  if (orders.length === 0) {
    const emptyState = document.createElement('div');
    emptyState.className = 'empty-state';
    emptyState.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
      <h3>No hay pedidos</h3>
      <p>No se encontraron pedidos que coincidan con tu búsqueda.</p>
    `;
    ordersContainer.appendChild(emptyState);
    return;
  }

  orders.forEach(order => {
    const orderCard = document.createElement('div');
    orderCard.className = `order-card ${order.estado === 'rejected' ? 'inactive' : ''}`;
    
    // Calculate total
    const total = order.productos.reduce((sum, product) => sum + (product.precio * product.cantidad), 0);
    
    // Create order header
    const orderHeader = document.createElement('div');
    orderHeader.className = 'order-header';
    
    const orderHeaderContent = document.createElement('div');
    orderHeaderContent.className = 'order-header-content';
    
    const orderTitle = document.createElement('div');
    orderTitle.className = 'order-title';
    orderTitle.textContent = `Pedido #${order.id} - ${order.cliente}`;
    
    const orderStatus = document.createElement('div');
    orderStatus.className = `status-indicator ${order.estado}`;
    
    // Set status text based on order state
    let statusText = '';
    switch(order.estado) {
      case 'pending':
        statusText = 'Pendiente';
        break;
      case 'accepted':
        statusText = 'Aceptado';
        break;
      case 'dispatched':
        statusText = 'Despachado';
        break;
      case 'rejected':
        statusText = 'Rechazado';
        break;
      default:
        statusText = 'Desconocido';
    }
    
    orderStatus.innerHTML = `
      <span class="status-dot ${order.estado}"></span>
      <span>${statusText}</span>
    `;
    
    const orderActions = document.createElement('div');
    orderActions.className = 'order-actions';
    
    if (order.estado === 'pending') {
      // Accept button
      const acceptButton = document.createElement('button');
      acceptButton.className = 'button button-secondary button-sm button-icon';
      acceptButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><polyline points="20 6 9 17 4 12"></polyline></svg>
        <span>Aceptar</span>
      `;
      acceptButton.addEventListener('click', () => handleOrderAction(order, 'accept'));
      orderActions.appendChild(acceptButton);
      
      // Reject button
      const rejectButton = document.createElement('button');
      rejectButton.className = 'button button-outline button-sm button-icon button-destructive';
      rejectButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        <span>Rechazar</span>
      `;
      rejectButton.addEventListener('click', () => handleOrderAction(order, 'reject'));
      orderActions.appendChild(rejectButton);
    } else if (order.estado === 'accepted') {
      // Dispatch button
      const dispatchButton = document.createElement('button');
      dispatchButton.className = 'button button-primary button-sm button-icon';
      dispatchButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon"><path d="M5 12h14"></path><path d="M12 5l7 7-7 7"></path></svg>
        <span>Despachar</span>
      `;
      dispatchButton.addEventListener('click', () => handleOrderAction(order, 'dispatch'));
      orderActions.appendChild(dispatchButton);
    }
    
    orderHeaderContent.appendChild(orderTitle);
    orderHeaderContent.appendChild(orderStatus);
    
    const orderDetails = document.createElement('div');
    orderDetails.className = 'order-details';
    orderDetails.innerHTML = `
      <p>Dirección: ${order.direccion}</p>
      <p>Fecha: ${order.fecha}</p>
    `;
    
    orderHeader.appendChild(orderHeaderContent);
    orderHeader.appendChild(orderDetails);
    orderHeader.appendChild(orderActions);
    
    // Create order content with products table
    const orderContent = document.createElement('div');
    orderContent.className = 'order-content';
    
    const tableContainer = document.createElement('div');
    tableContainer.className = 'table-container';
    
    const table = document.createElement('table');
    
    const tableHead = document.createElement('thead');
    tableHead.innerHTML = `
      <tr>
        <th>Producto</th>
        <th class="text-right">Precio</th>
        <th class="text-right">Cantidad</th>
        <th class="text-right">Subtotal</th>
      </tr>
    `;
    
    const tableBody = document.createElement('tbody');
    
    // Add product rows
    order.productos.forEach(product => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td class="font-medium">${product.nombre}</td>
        <td class="text-right">$${product.precio.toLocaleString()}</td>
        <td class="text-right">${product.cantidad}</td>
        <td class="text-right">$${(product.precio * product.cantidad).toLocaleString()}</td>
      `;
      tableBody.appendChild(row);
    });
    
    // Add total row
    const totalRow = document.createElement('tr');
    totalRow.innerHTML = `
      <td colspan="3" class="text-right font-bold">Total:</td>
      <td class="text-right font-bold">$${total.toLocaleString()}</td>
    `;
    tableBody.appendChild(totalRow);
    
    table.appendChild(tableHead);
    table.appendChild(tableBody);
    tableContainer.appendChild(table);
    orderContent.appendChild(tableContainer);
    
    // Assemble the order card
    orderCard.appendChild(orderHeader);
    orderCard.appendChild(orderContent);
    
    ordersContainer.appendChild(orderCard);
  });
}

// Handle order action (accept, reject, or dispatch)
function handleOrderAction(order, action) {
  selectedOrder = order;
  dialogAction = action;
  
  if (action === 'accept') {
    dialogTitle.textContent = '¿Aceptar pedido?';
    dialogDescription.textContent = 'Este pedido será aceptado para su preparación.';
    dialogConfirmButton.textContent = 'Aceptar pedido';
    dialogConfirmButton.className = 'button button-secondary';
  } else if (action === 'reject') {
    dialogTitle.textContent = '¿Rechazar pedido?';
    dialogDescription.textContent = 'Este pedido será rechazado y no se procesará.';
    dialogConfirmButton.textContent = 'Rechazar pedido';
    dialogConfirmButton.className = 'button button-destructive';
  } else if (action === 'dispatch') {
    dialogTitle.textContent = '¿Marcar como despachado?';
    dialogDescription.textContent = 'Este pedido será marcado como despachado al cliente.';
    dialogConfirmButton.textContent = 'Marcar como despachado';
    dialogConfirmButton.className = 'button';
  }
  
  // Calculate total
  const total = selectedOrder.productos.reduce((sum, product) => sum + (product.precio * product.cantidad), 0);
  
  dialogContent.innerHTML = `
    <p><strong>Cliente:</strong> ${selectedOrder.cliente}</p>
    <p><strong>Dirección:</strong> ${selectedOrder.direccion}</p>
    <p><strong>Total:</strong> $${total.toLocaleString()}</p>
  `;
  
  openDialog();
}

// Open dialog
function openDialog() {
  dialogOverlay.classList.remove('hidden');
  dialogOverlay.classList.add('dialog-overlay');
}

// Close dialog
function closeDialog() {
  dialogOverlay.classList.add('hidden');
  dialogOverlay.classList.remove('dialog-overlay');
}

// Confirm order action
function confirmOrderAction() {
  if (!selectedOrder) return;
  
  let newStatus = '';
  let actionText = '';
  
  switch (dialogAction) {
    case 'accept':
      newStatus = 'accepted';
      actionText = 'aceptado';
      break;
    case 'reject':
      newStatus = 'rejected';
      actionText = 'rechazado';
      break;
    case 'dispatch':
      newStatus = 'dispatched';
      actionText = 'despachado';
      break;
    default:
      return;
  }
  
  // Update the order status in our example data
  const orderIndex = exampleOrders.findIndex(order => order.id === selectedOrder.id);
  if (orderIndex !== -1) {
    exampleOrders[orderIndex].estado = newStatus;
    
    showToast(
      `Pedido ${actionText}`, 
      `El pedido #${selectedOrder.id} ha sido ${actionText} correctamente.`
    );
    
    // Reload orders to reflect changes
    loadOrders(orderSearchInput.value);
  } else {
    showToast('Error', 'No se pudo actualizar el estado del pedido.');
  }
  
  closeDialog();
}

// Show toast notification
function showToast(title, message) {
  toastTitle.textContent = title;
  toastMessage.textContent = message;
  
  toast.classList.remove('hidden');
  
  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', init);