from .models import Carrito

def total_carrito(request):
    if request.user.is_authenticated:
        try:
            carrito = Carrito.objects.get(usuario=request.user)
            total = sum(item.producto.precio_clp * item.cantidad for item in carrito.items.all())
            cantidad = sum(item.cantidad for item in carrito.items.all())
            return {'total_carrito': total, 'cantidad_items': cantidad}
        except Carrito.DoesNotExist:
            return {'total_carrito': 0, 'cantidad_items': 0}
    return {'total_carrito': 0, 'cantidad_items': 0}
