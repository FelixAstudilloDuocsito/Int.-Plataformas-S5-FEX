from django import forms
from .models import Carrito

class CarritoForm(forms.ModelForm):
    class Meta:
        model = Carrito
        fields = ['opcion_entrega']
        widgets = {
            'opcion_entrega': forms.Select(attrs={'class': 'form-control'}),
        }


from django import forms

class OpcionEntregaForm(forms.Form):
    # Tipo de entrega: envío o retiro
    opcion = forms.ChoiceField(
        choices=[
            ('envio', 'Envío a domicilio'),
            ('retiro', 'Retiro en tienda'),
        ],
        widget=forms.RadioSelect,
        label="Seleccione opción de entrega"
    )
    
    # Campos para envío
    nombre_destinatario = forms.CharField(
        max_length=100,
        required=False,  # Será requerido solo si opción = envio
        label="Nombre del destinatario",
        widget=forms.TextInput(attrs={'placeholder': 'Nombre completo'})
    )
    
    direccion_envio = forms.CharField(
        max_length=250,
        required=False,
        label="Dirección de envío",
        widget=forms.TextInput(attrs={'placeholder': 'Calle, número, comuna, ciudad'})
    )
    
    telefono_contacto = forms.CharField(
        max_length=15,
        required=False,
        label="Teléfono de contacto",
        widget=forms.TextInput(attrs={'placeholder': 'Número de teléfono'})
    )
    
    # Campo para fecha preferida de entrega (opcional)
    fecha_entrega = forms.DateField(
        required=False,
        widget=forms.DateInput(attrs={'type': 'date'}),
        label="Fecha preferida de entrega (opcional)"
    )
    
    # Campo para horario preferido de entrega (opcional)
    horario_entrega = forms.ChoiceField(
        choices=[
            ('manana', 'Mañana (8:00 - 12:00)'),
            ('tarde', 'Tarde (12:00 - 18:00)'),
            ('noche', 'Noche (18:00 - 21:00)'),
        ],
        required=False,
        label="Horario preferido de entrega"
    )
    
    # Validación personalizada para que algunos campos sean obligatorios solo si opcion=envio
    def clean(self):
        cleaned_data = super().clean()
        opcion = cleaned_data.get('opcion')
        
        if opcion == 'envio':
            if not cleaned_data.get('nombre_destinatario'):
                self.add_error('nombre_destinatario', 'Este campo es obligatorio para envío.')
            if not cleaned_data.get('direccion_envio'):
                self.add_error('direccion_envio', 'Este campo es obligatorio para envío.')
            if not cleaned_data.get('telefono_contacto'):
                self.add_error('telefono_contacto', 'Este campo es obligatorio para envío.')
        
        return cleaned_data









from django import forms

class EntregaForm(forms.Form):
    METODOS = [
        ('domicilio', 'Envío a domicilio'),
        ('tienda', 'Retiro en tienda'),
    ]
    metodo_entrega = forms.ChoiceField(choices=METODOS, widget=forms.RadioSelect, required=True)

    # Campos para domicilio
    nombre = forms.CharField(min_length=3, max_length=100, required=False)
    telefono = forms.CharField(min_length=9, max_length=9, required=False)
    direccion = forms.CharField(min_length=5, max_length=200, required=False)
    email = forms.EmailField(required=False)
    ciudad = forms.CharField(min_length=2, max_length=100, required=False)

    # Campos para tienda
    nombre_tienda = forms.CharField(min_length=3, max_length=100, required=False)
    telefono_tienda = forms.CharField(min_length=9, max_length=9, required=False)
    email_tienda = forms.EmailField(required=False)

    def clean(self):
        cleaned_data = super().clean()
        metodo = cleaned_data.get('metodo_entrega')

        if metodo == 'domicilio':
            # Validar campos domicilio obligatorios
            for field in ['nombre', 'telefono', 'direccion', 'email', 'ciudad']:
                if not cleaned_data.get(field):
                    self.add_error(field, 'Este campo es obligatorio para envío a domicilio.')

            # Teléfono numérico exacto 9 dígitos
            telefono = cleaned_data.get('telefono')
            if telefono and (not telefono.isdigit() or len(telefono) != 9):
                self.add_error('telefono', 'Teléfono debe tener 9 dígitos numéricos.')

        elif metodo == 'tienda':
            # Validar campos tienda obligatorios
            for field in ['nombre_tienda', 'telefono_tienda', 'email_tienda']:
                if not cleaned_data.get(field):
                    self.add_error(field, 'Este campo es obligatorio para retiro en tienda.')

            telefono_tienda = cleaned_data.get('telefono_tienda')
            if telefono_tienda and (not telefono_tienda.isdigit() or len(telefono_tienda) != 9):
                self.add_error('telefono_tienda', 'Teléfono debe tener 9 dígitos numéricos.')

        else:
            raise forms.ValidationError('Debes seleccionar un método de entrega válido.')

        return cleaned_data



