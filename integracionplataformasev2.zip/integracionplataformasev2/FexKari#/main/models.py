#MODELS.PY

from django.db import models

from django.utils.text import slugify

class Categoria(models.Model):
    nombre = models.CharField(max_length=100)
    slug = models.SlugField(blank=True)  # ← QUITA unique=True TEMPORALMENTE



    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.nombre)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.nombre



class Producto(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=255)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE, related_name='productos')
    precio_clp = models.PositiveIntegerField()
    marca = models.CharField(max_length=100, blank=True)
    stock = models.PositiveIntegerField(default=0)
    descripcion = models.TextField(blank=True)

    def __str__(self):
        return f"{self.nombre} - {self.codigo}"
    
class ImagenProducto(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='imagenes')
    archivo = models.CharField(max_length=100)  # ej: "HM-001.jpg" o "martillo2.png"

    def __str__(self):
        return f"Imagen de {self.producto.nombre}: {self.archivo}"
    


from django.contrib.auth.models import User

class Carrito(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)
    opcion_entrega = models.ForeignKey('OpcionEntrega', on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"Carrito de {self.usuario.username}"



class ItemCarrito(models.Model):
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"


class OpcionEntrega(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True)
    precio = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.nombre} - ${self.precio}"


