from django.urls import path
from . import views

urlpatterns = [
    path('', views.vista1, name='home'), 
    path('login/', views.login, name='login'),
    path('vista1/', views.vista1, name='vista1'),
    path('Hmanuales/', views.Hmanuales, name='Hmanuales'),
    path('Helctricasmanuales/', views.Helctricasmanuales, name='Helctricasmanuales'),
    path('HerramientasElectricasEstacionarias/', views.HerramientasElectricasEstacionarias, name='HerramientasElectricasEstacionarias'),
    path('HerramientasCorte/', views.HerramientasCorte, name='HerramientasCorte'),
    path('HerramientasMedicion/', views.HerramientasMedicion, name='HerramientasMedicion'),
    path('HerramientasJardineria/', views.HerramientasJardineria, name='HerramientasJardineria'),
    path('HerramientasGasfiteria/', views.HerramientasGasfiteria, name='HerramientasGasfiteria'),
    path('HerramientasElectricidad/', views.HerramientasElectricidad, name='HerramientasElectricidad'),
    path('HeraminetasMecanicaAutomotriz/', views.HeraminetasMecanicaAutomotriz, name='HeraminetasMecanicaAutomotriz'),
    path('EquiposSeguridad/', views.EquiposSeguridad, name='EquiposSeguridad'),
    path('FijacionesAdhesivos/', views.FijacionesAdhesivos, name='FijacionesAdhesivos'),
    path('TornillosAnclajesMas/', views.TornillosAnclajesMas, name='TornillosAnclajesMas'),
    path('Eligenos/', views.Eligenos, name='Eligenos'),
    path('Nosotros/', views.Nosotros, name='Nosotros'),
    path('MaterialesConstruccion/', views.MaterialesConstruccion, name='MaterialesConstruccion'),
    path('verCarrito/', views.verCarrito, name='verCarrito'),
    path('agregaralcarrito/<int:producto_id>/', views.agregaralcarrito, name='agregaralcarrito'),
    path('carrito/eliminar/<int:item_id>/', views.eliminar_del_carrito, name='eliminar_del_carrito'),

]




# la vista 1 es el inicio 
