from django import template

register = template.Library()

@register.filter
def contiene(productos, keyword):
    return [p for p in productos if keyword.lower() in p.nombre.lower()]
