#VIEWS.PY


from django.shortcuts import render
from .models import Producto

def login(request):
    return render(request, 'main/login.html')

def vista1(request):
    return render(request, 'main/vista1.html')

def vendedor(request):
    return render(request, 'main/vendedor.html')

def bodeguero(request):
    return render(request, 'main/bodeguero.html')

def contador(request):
    return render(request, 'main/contador.html')

def administrador(request):
    return render(request, 'main/administrador.html')




def Hmanuales(request):
    return render(request, 'main/Hmanuales.html')

def Helctricasmanuales(request):
    return render(request, 'main/Helctricasmanuales.html')

def HerramientasElectricasEstacionarias(request):
    return render(request, 'main/HerramientasElectricasEstacionarias.html')

def HerramientasCorte(request):
    return render(request, 'main/HerramientasCorte.html')

def HerramientasMedicion(request):
    return render(request, 'main/HerramientasMedicion.html')

def HerramientasJardineria(request):
    return render(request, 'main/HerramientasJardineria.html')

def HerramientasGasfiteria(request):
    return render(request, 'main/HerramientasGasfiteria.html')

def HerramientasElectricidad(request):
    return render(request, 'main/HerramientasElectricidad')

def HeraminetasMecanicaAutomotriz(request):
    return render(request, 'main/HeraminetasMecanicaAutomotriz.html')

def EquiposSeguridad(request):
    return render(request, 'main/EquiposSeguridad.html')

def FijacionesAdhesivos(request):
    return render(request, 'main/FijacionesAdhesivos.html')

def TornillosAnclajesMas(request):
    return render(request, 'main/TornillosAnclajesMas.html')

def Eligenos(request):
    return render(request, 'main/Eligenos.html')

def Nosotros(request):
    return render(request, 'main/Nosotros.html')

def MaterialesConstruccion(request):
    return render(request, 'main/MaterialesConstruccion.html')

def productos_por_categoria_agrupada(request, nombre_categoria, template_html, agrupaciones):
    productos = Producto.objects.filter(categoria__nombre=nombre_categoria)
    return render(request, f'main/{template_html}', {
        'productos': productos,
        'agrupaciones': agrupaciones,
        'nombre_categoria': nombre_categoria
    })




def Hmanuales(request):
    agrupaciones = [
        ("Martillo", "Martillos"),
        ("Destornillador", "Destornilladores"),
        ("Llave", "Llaves"),
        ("Alicate", "Alicates"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas Manuales", "Hmanuales.html", agrupaciones)

def Helctricasmanuales(request):
    agrupaciones = [
        ("Taladro", "Taladros"),
        ("Sierra", "Sierras"),
        ("Lijadora", "Lijadoras"),
        ("Pistola", "Pistolas de Calor"),
        ("Cautín", "Cautines"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas Eléctricas Portátiles", "Helctricasmanuales.html", agrupaciones)

def HerramientasElectricasEstacionarias(request):
    agrupaciones = [
        ("Sierra", "Sierras de Banco"),
        ("Compresor", "Compresores"),
        ("Generador", "Generadores"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas Eléctricas Estacionarias", "HerramientasElectricasEstacionarias.html", agrupaciones)

def HerramientasCorte(request):
    agrupaciones = [
        ("Sierra", "Sierras"),
        ("Serrucho", "Serruchos"),
        ("Arco", "Arcos"),
        ("Ingletadora", "Ingletadoras"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Corte", "HerramientasCorte.html", agrupaciones)

def HerramientasMedicion(request):
    agrupaciones = [
        ("Nivelador", "Niveladores"),
        ("Wincha", "Winchas"),
        ("Escuadra", "Escuadras"),
        ("Calibrador", "Calibradores"),
        ("Multímetro", "Multímetros"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Medición", "HerramientasMedicion.html", agrupaciones)

def HerramientasJardineria(request):
    agrupaciones = [
        ("Azada", "Azadas"),
        ("Pala", "Palas"),
        ("Tijera", "Tijeras de poda"),
        ("Escoba", "Escobas"),
        ("Bordeadora", "Bordedoras"),
        ("Manguera", "Mangueras"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Jardinería", "HerramientasJardineria.html", agrupaciones)

def HerramientasGasfiteria(request):
    agrupaciones = [
        ("Llave", "Llaves"),
        ("Cinta", "Cintas"),
        ("Adhesivo", "Adhesivos"),
        ("Pinza", "Pinzas"),
        ("Juego", "Juegos de Herramientas"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Gasfitería", "HerramientasGasfiteria.html", agrupaciones)

def HerramientasElectricidad(request):
    agrupaciones = [
        ("Multímetro", "Multímetros"),
        ("Detector", "Detectores"),
        ("Linterna", "Linternas"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Electricidad", "HerramientasElectricidad.html", agrupaciones)

def HeraminetasMecanicaAutomotriz(request):
    agrupaciones = [
        ("Gato", "Gatos Hidráulicos"),
        ("Abrazadera", "Abrazaderas"),
        ("Multímetro", "Multímetros"),
    ]
    return productos_por_categoria_agrupada(request, "Herramientas de Mecánica Automotriz", "HeraminetasMecanicaAutomotriz.html", agrupaciones)

def EquiposSeguridad(request):
    agrupaciones = [
        ("Casco", "Cascos"),
        ("Guante", "Guantes"),
        ("Lente", "Lentes"),
    ]
    return productos_por_categoria_agrupada(request, "Equipos de Seguridad", "EquiposSeguridad.html", agrupaciones)

def TornillosAnclajesMas(request):
    agrupaciones = [
        ("Tornillo", "Tornillos"),
        ("Anclaje", "Anclajes"),
        ("Taco", "Tacos y Fijaciones"),
    ]
    return productos_por_categoria_agrupada(request, "Tornillos y Anclajes", "TornillosAnclajesMas.html", agrupaciones)

def FijacionesAdhesivos(request):
    agrupaciones = [
        ("Clavo", "Clavos"),
        ("Abrazadera", "Abrazaderas"),
        ("Remache", "Remaches"),
        ("Velcro", "Velcros"),
        ("Silicona", "Siliconas"),
        ("Adhesivo", "Adhesivos"),
        ("Epóxico", "Epóxicos"),
        ("Cinta", "Cintas"),
    ]
    return productos_por_categoria_agrupada(request, "Fijaciones y Adhesivos", "FijacionesAdhesivos.html", agrupaciones)

def MaterialesConstruccion(request):
    agrupaciones = [
        ("Cemento", "Cementos"),
        ("Arena", "Arena"),
        ("Ladrillo", "Ladrillos"),
        ("Pintura", "Pinturas"),
        ("Barniz", "Barnices"),
        ("Cerámico", "Cerámicos"),
    ]
    return productos_por_categoria_agrupada(request, "Materiales de Construcción", "MaterialesConstruccion.html", agrupaciones)


# hacerlo mismo con cada categoria/html de productos  es para que todos los productos e imagnes se vean en sus respectivas vistas 
#falta agregar los precios de los productos 


from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Carrito, ItemCarrito

@login_required
def agregaralcarrito(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    carrito, _ = Carrito.objects.get_or_create(usuario=request.user)
    item, creado = ItemCarrito.objects.get_or_create(carrito=carrito, producto=producto)
    
    if not creado:
        item.cantidad += 1
        item.save()
    
    return redirect('verCarrito')


@login_required
def verCarrito(request):
    carrito, _ = Carrito.objects.get_or_create(usuario=request.user)
    items = carrito.items.select_related('producto')
    total = sum(item.producto.precio_clp * item.cantidad for item in items)
    
    return render(request, 'main/verCarrito.html', {
        'items': items,
        'total': total,
    })


@login_required
def eliminar_del_carrito(request, item_id):
    item = get_object_or_404(ItemCarrito, id=item_id, carrito__usuario=request.user)
    item.delete()
    return redirect('verCarrito')

from django.shortcuts import render, redirect
from .models import Carrito, ItemCarrito
from .forms import CarritoForm, OpcionEntregaForm
from django.contrib.auth.decorators import login_required

@login_required
def carrito_pago(request):
    carrito, _ = Carrito.objects.get_or_create(usuario=request.user)
    items = carrito.items.all()

    if request.method == 'POST':
        form = OpcionEntregaForm(request.POST)
        if form.is_valid():
            opcion_entrega = form.cleaned_data['opcion_entrega']
            carrito.opcion_entrega = opcion_entrega
            carrito.save()
            return redirect('confirmacion_pago')  # Cambia según tu URL real
    else:
        form = OpcionEntregaForm(initial={'opcion_entrega': carrito.opcion_entrega})

    subtotal = sum(item.producto.precio_clp * item.cantidad for item in items)
    precio_entrega = carrito.opcion_entrega.precio if carrito.opcion_entrega else 0
    total = subtotal + precio_entrega

    contexto = {
        'items': items,
        'form': form,
        'subtotal': subtotal,
        'precio_entrega': precio_entrega,
        'total': total,
    }
    return render(request, 'carrito_pago.html', contexto)


from django.contrib.auth.decorators import login_required







def opcion_entrega(request):
    carrito = request.session.get('carrito', {})
    productos = []
    total = 0

    for item_id, item_data in carrito.items():
        try:
            producto = Producto.objects.get(id=item_id)
            subtotal = producto.precio * item_data['cantidad']
            productos.append({
                'nombre': producto.nombre,
                'cantidad': item_data['cantidad'],
                'precio': producto.precio,
                'total': subtotal
            })
            total += subtotal
        except Producto.DoesNotExist:
            continue

    return render(request, 'main/opcion_entrega.html', {
        'productos_carrito': productos,
        'total_carrito': total
    })


from django.shortcuts import render, redirect
from .forms import EntregaForm

# Simulación carrito guardado en sesión con productos
PRODUCTOS_DE_EJEMPLO = [
    {'id': 1, 'nombre': 'Taladro inalámbrico', 'precio': 59000, 'cantidad': 2},
    {'id': 2, 'nombre': 'Set destornilladores', 'precio': 15000, 'cantidad': 1},
]

def obtener_carrito(request):
    # Si no hay carrito en sesión, ponemos el ejemplo
    carrito = request.session.get('carrito')
    if not carrito:
        request.session['carrito'] = PRODUCTOS_DE_EJEMPLO
        carrito = PRODUCTOS_DE_EJEMPLO
    return carrito

def entrega_view(request):
    carrito = obtener_carrito(request)

    if request.method == 'POST':
        form = EntregaForm(request.POST)
        if form.is_valid():
            # Guardar info o procesar pedido (simulado)
            request.session['datos_entrega'] = form.cleaned_data
            return redirect('confirmacion_entrega')
    else:
        form = EntregaForm()

    total = sum(p['precio'] * p['cantidad'] for p in carrito)

    return render(request, 'opcion_entrega.html', {
        'form': form,
        'carrito': carrito,
        'total': total,
    })

def confirmacion_view(request):
    datos_entrega = request.session.get('datos_entrega')
    carrito = obtener_carrito(request)
    total = sum(p['precio'] * p['cantidad'] for p in carrito)

    if not datos_entrega:
        return redirect('entrega')

    return render(request, 'confirmacion.html', {
        'datos_entrega': datos_entrega,
        'carrito': carrito,
        'total': total,
    })





# main/views.py (o la app que estés usando)

from django.shortcuts import render, redirect

def procesar_entrega(request):
    if request.method == 'POST':
        metodo = request.POST.get('metodo_entrega')

        if metodo == 'domicilio':
            nombre = request.POST.get('nombre')
            direccion = request.POST.get('direccion')
            ciudad = request.POST.get('ciudad')
            telefono = request.POST.get('telefono')
            email = request.POST.get('email')
            # Aquí podrías validar datos o guardarlos

        elif metodo == 'tienda':
            sucursal = request.POST.get('sucursal')
            nombre_tienda = request.POST.get('nombre_tienda')
            telefono_tienda = request.POST.get('telefono_tienda')
            email_tienda = request.POST.get('email_tienda')
            # Aquí también validar o guardar

        # Después de procesar, puedes redirigir a la página de pago, por ejemplo:
        return redirect('pagina_pago')  # Cambia 'pagina_pago' por la URL que corresponda

    # Si alguien accede por GET, puedes mostrar el formulario (opcional)
    return render(request, 'opcion_entrega.html')


def verificar_codigo_producto(request):
    codigo = request.GET.get('codigo', '')
    existe = Producto.objects.filter(codigo=codigo).exists()
    return JsonResponse({'existe': existe})



# views.py
import stripe
from django.conf import settings
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse

stripe.api_key = settings.STRIPE_SECRET_KEY

def checkout(request):
    return render(request, 'main/pagina_pago.html', {
        'stripe_publishable_key': settings.STRIPE_PUBLISHABLE_KEY
    })

import json


import stripe
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

stripe.api_key = settings.STRIPE_SECRET_KEY  # tu clave secreta Stripe

@csrf_exempt  # o asegúrate de usar el CSRF token en el fetch
def create_checkout_session(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        total_amount = data.get('total_amount')  # el monto que envía el frontend

        try:
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'clp',  # pesos chilenos
                        'product_data': {
                            'name': 'Compra en Mi Tienda',
                        },
                        'unit_amount': total_amount,
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url='https://tu-sitio.com/success',  # cambia por URL real
                cancel_url='https://tu-sitio.com/cancel',    # cambia por URL real
            )
            return JsonResponse({'id': checkout_session.id})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=400)
    else:
        return JsonResponse({'error': 'Método no permitido'}, status=405)


def success(request):
    return render(request, 'main/success.html')

def cancel(request):
    return render(request, 'main/cancel.html')



