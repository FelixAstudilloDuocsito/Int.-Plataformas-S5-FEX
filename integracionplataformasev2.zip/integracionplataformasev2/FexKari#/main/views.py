from django.shortcuts import render
from .models import Producto

def login(request):
    return render(request, 'main/login.html')

def vista1(request):
    return render(request, 'main/vista1.html')


def Hmanuales(request):
    return render(request, 'main/Hmanuales.html')

def Helctricasmanuales(request):
    return render(request, 'main/Helctricasmanuales.html')

def HerramientasElectricasEstacionarias(request):
    return render(request, 'main/HerramientasElectricasEstacionarias.html')

def HerramientasCorte(request):
    return render(request, 'main/HerramientasCorte.html')

def HerramientasMedicion(request):
    return render(request, 'main/HerramientasMedicion.html')

def HerramientasJardineria(request):
    return render(request, 'main/HerramientasJardineria.html')

def HerramientasGasfiteria(request):
    return render(request, 'main/HerramientasGasfiteria.html')

def HerramientasElectricidad(request):
    return render(request, 'main/HerramientasElectricidad')

def HeraminetasMecanicaAutomotriz(request):
    return render(request, 'main/HeraminetasMecanicaAutomotriz.html')

def EquiposSeguridad(request):
    return render(request, 'main/EquiposSeguridad.html')

def FijacionesAdhesivos(request):
    return render(request, 'main/FijacionesAdhesivos.html')

def TornillosAnclajesMas(request):
    return render(request, 'main/TornillosAnclajesMas.html')

def Eligenos(request):
    return render(request, 'main/Eligenos.html')

def Nosotros(request):
    return render(request, 'main/Nosotros.html')

def MaterialesConstruccion(request):
    return render(request, 'main/MaterialesConstruccion.html')



def Hmanuales(request):
    productos = Producto.objects.filter(categoria__nombre="Herramientas Manuales")

    agrupaciones = [
        ("Martillo", "Martillos"),
        ("Destornillador", "Destornilladores"),
        ("Llave", "Llaves"),
        ("Alicate", "Alicates"),
        ("Taladro", "Taladros"),
        ("Sierra", "Sierras"),
        ("Lijadora", "Lijadoras"),
    ]

    return render(request, 'main/Hmanuales.html', {
        'productos': productos,
        'agrupaciones': agrupaciones
    })

# hacerlo mismo con cada categoria/html de productos  es para que todos los productos e imagnes se vean en sus respectivas vistas 
#falta agregar los precios de los productos 


from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Carrito, ItemCarrito

@login_required
def agregaralcarrito(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    carrito, _ = Carrito.objects.get_or_create(usuario=request.user)
    item, creado = ItemCarrito.objects.get_or_create(carrito=carrito, producto=producto)
    
    if not creado:
        item.cantidad += 1
        item.save()
    
    return redirect('verCarrito')


@login_required
def verCarrito(request):
    carrito, _ = Carrito.objects.get_or_create(usuario=request.user)
    items = carrito.items.select_related('producto')
    total = sum(item.producto.precio_clp * item.cantidad for item in items)
    
    return render(request, 'main/verCarrito.html', {
        'items': items,
        'total': total,
    })


@login_required
def eliminar_del_carrito(request, item_id):
    item = get_object_or_404(ItemCarrito, id=item_id, carrito__usuario=request.user)
    item.delete()
    return redirect('verCarrito')

