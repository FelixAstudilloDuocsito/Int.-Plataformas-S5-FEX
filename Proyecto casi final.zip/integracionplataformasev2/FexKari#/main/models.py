from django.db import models

class Categoria(models.Model):
    nombre = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.nombre


class Producto(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=255)
    categoria = models.ForeignKey(Categoria, on_delete=models.CASCADE, related_name='productos')
    precio_clp = models.PositiveIntegerField()
    marca = models.CharField(max_length=100, blank=True)
    stock = models.PositiveIntegerField(default=0)
    descripcion = models.TextField(blank=True)

    def __str__(self):
        return f"{self.nombre} - {self.codigo}"
    
class ImagenProducto(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='imagenes')
    archivo = models.CharField(max_length=100)  # ej: "HM-001.jpg" o "martillo2.png"

    def __str__(self):
        return f"Imagen de {self.producto.nombre}: {self.archivo}"
    


from django.contrib.auth.models import User

class Carrito(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"Carrito de {self.usuario.username}"


class ItemCarrito(models.Model):
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE, related_name='items')
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.cantidad} x {self.producto.nombre}"
